const http = require("node:http");
const { createHash } = require("node:crypto");
const { readFile } = require("node:fs/promises");
const path = require("node:path");
const { URL } = require("node:url");

const PORT = Number(process.env.PORT || process.env.RADAR_PORT || 3000);
const PUBLIC_DIR = path.join(__dirname, "public");
const TIME_ZONE = "America/Sao_Paulo";

const SOURCES = [
  {
    id: "curadoria",
    name: "Curadoria manual",
    url: "https://www.google.com/search?q=agenda+cultural+Curitiba+2026",
    mode: "curadoria",
    reliability: "alta",
    note: "Lista editorial com shows internacionais e grandes atracoes culturais confirmadas."
  },
  {
    id: "comedy-club",
    name: "Curitiba Comedy Club",
    url: "https://comedy.com.br/programacao/",
    mode: "automatico",
    reliability: "alta",
    note: "Programacao oficial de stand-up e comedia em Curitiba."
  },
  {
    id: "curitiba-cult",
    name: "Curitiba Cult",
    url: "https://curitibacult.com.br/",
    feedUrl: "https://curitibacult.com.br/feed/",
    mode: "rss",
    reliability: "radar",
    note: "Radar automatico de noticias culturais; itens entram como checagem."
  },
  {
    id: "canalhas",
    name: "Clube dos Canalhas",
    url: "https://canalhascomedy.com.br/",
    mode: "curadoria",
    reliability: "alta",
    note: "Agenda oficial do grupo de humor Clube dos Canalhas."
  },
  {
    id: "teatro-guaira",
    name: "Teatro Guaira",
    url: "https://www.teatroguaira.pr.gov.br/",
    mode: "oficial",
    reliability: "alta",
    note: "Fonte oficial para teatro, musica e grandes espetaculos no Guaira."
  },
  {
    id: "eventim",
    name: "Eventim",
    url: "https://www.eventim.com.br/",
    mode: "bilheteria",
    reliability: "alta",
    note: "Bilheteria usada para turnes e espetaculos de grande porte."
  },
  {
    id: "cirque",
    name: "Cirque du Soleil",
    url: "https://cirquealegria.com.br/",
    mode: "oficial",
    reliability: "alta",
    note: "Pagina oficial da temporada Alegria no Brasil."
  },
  {
    id: "fastix",
    name: "FasTix",
    url: "https://fastix.com.br/",
    mode: "bilheteria",
    reliability: "alta",
    note: "Bilheteria usada para shows de grande porte."
  }
];

const CURATED_EVENTS = [
  {
    artist: "Echo & The Bunnymen",
    title: "Somos Rock Festival 2026",
    subtitle: "Echo & The Bunnymen, Spin Doctors, Smash Mouth e Candlebox no mesmo dia",
    date: "2026-04-26",
    startTime: "10:00",
    venue: "Pedreira Paulo Leminski",
    neighborhood: "Abranches",
    genre: "Post-punk / rock alternativo",
    scope: "Reino Unido + EUA",
    track: "international",
    tier: "headliner",
    relevance: 96,
    price: "Consultar ingressos",
    sourceId: "curadoria",
    source: "Curadoria manual",
    url: "https://underfloripa.com.br/agenda/somos-rock/",
    sourceUrl: "https://underfloripa.com.br/agenda/somos-rock/",
    lineup: ["Echo & The Bunnymen", "Spin Doctors", "Smash Mouth", "Candlebox"],
    tags: ["festival", "rock", "anos 80", "anos 90", "internacional"],
    whyRelevant: "Festival com quatro nomes internacionais conhecidos, incluindo um headliner britanico de post-punk."
  },
  {
    artist: "Dream Theater",
    title: "Dream Theater - Curitiba 2026",
    subtitle: "Turne de metal progressivo no Live Curitiba",
    date: "2026-05-05",
    startTime: "18:30",
    venue: "Live Curitiba",
    neighborhood: "Novo Mundo",
    genre: "Metal progressivo",
    scope: "EUA",
    track: "international",
    tier: "headliner",
    relevance: 95,
    price: "Consultar ingressos",
    sourceId: "curadoria",
    source: "Curadoria manual",
    url: "https://fastix.com.br/events/dream-theater-2026-curitiba",
    sourceUrl: "https://fastix.com.br/events/dream-theater-2026-curitiba",
    lineup: ["Dream Theater"],
    tags: ["metal", "progressivo", "virtuose", "internacional"],
    whyRelevant: "Banda internacional de grande porte para publico de metal progressivo, com data e casa confirmadas."
  },
  {
    artist: "Men At Work",
    title: "Men At Work - Curitiba",
    subtitle: "Pop rock australiano no Igloo Super Hall",
    date: "2026-05-12",
    startTime: "19:00",
    venue: "Igloo Super Hall",
    neighborhood: "Taruma",
    genre: "Pop rock / new wave",
    scope: "Australia",
    track: "international",
    tier: "headliner",
    relevance: 89,
    price: "Consultar ingressos",
    sourceId: "curadoria",
    source: "Curadoria manual",
    url: "https://eevento.com.br/evento/men-at-work",
    sourceUrl: "https://eevento.com.br/evento/men-at-work",
    lineup: ["Men At Work"],
    tags: ["pop rock", "new wave", "classicos", "internacional"],
    whyRelevant: "Nome internacional classico do pop rock australiano, em venue dedicado a shows."
  },
  {
    artist: "Rush",
    title: "Rush - Fifty Something South American Tour",
    subtitle: "Turne de estadio com abertura da rota sul-americana em Curitiba",
    date: "2027-01-22",
    startTime: "20:00",
    venue: "Arena da Baixada",
    neighborhood: "Agua Verde",
    genre: "Rock progressivo",
    scope: "Canada",
    track: "international",
    tier: "stadium",
    relevance: 100,
    price: "A partir de valores divulgados pela organizacao",
    sourceId: "curadoria",
    source: "Curadoria manual",
    url: "https://cwblive.com/rush-se-apresenta-no-dia-22-de-janeiro-de-2027-na-arena-da-baixada/",
    sourceUrl: "https://cwblive.com/rush-se-apresenta-no-dia-22-de-janeiro-de-2027-na-arena-da-baixada/",
    lineup: ["Rush"],
    tags: ["rock", "progressivo", "estadio", "internacional"],
    whyRelevant: "Show de estadio e uma das datas internacionais mais fortes ja anunciadas para Curitiba."
  },
  {
    artist: "Clube dos Canalhas",
    title: "Gravacao Especial 2026",
    subtitle: "Humor nacional em Curitiba",
    date: "2026-05-17",
    startTime: "20:00",
    venue: "Curitiba/PR - confirmar local no ingresso",
    genre: "Comedia / humor",
    scope: "Brasil",
    track: "comedy",
    tier: "comedy",
    relevance: 88,
    price: "Consultar ingressos",
    sourceId: "canalhas",
    source: "Clube dos Canalhas",
    url: "https://canalhascomedy.com.br/",
    sourceUrl: "https://canalhascomedy.com.br/",
    lineup: ["Clube dos Canalhas"],
    tags: ["comedia", "stand-up", "humor", "curitiba"],
    whyRelevant: "Grupo de humor com data confirmada em Curitiba na agenda oficial da turne."
  },
  {
    artist: "Gregorio Duvivier",
    title: "O Ceu da Lingua",
    subtitle: "Monologo comico no Teatro Guaira",
    date: "2026-06-22",
    startTime: "19:00",
    venue: "Teatro Guaira",
    neighborhood: "Centro",
    genre: "Monologo comico / teatro",
    scope: "Brasil",
    track: "comedy",
    tier: "culture",
    relevance: 90,
    price: "Consultar ingressos",
    sourceId: "curitiba-cult",
    source: "Curitiba Cult",
    url: "https://curitibacult.com.br/gregorio-duvivier-anuncia-sessoes-do-espetaculo-o-ceu-da-lingua-em-curitiba/",
    sourceUrl: "https://curitibacult.com.br/gregorio-duvivier-anuncia-sessoes-do-espetaculo-o-ceu-da-lingua-em-curitiba/",
    lineup: ["Gregorio Duvivier"],
    tags: ["comedia", "teatro", "monologo", "guaira"],
    whyRelevant: "Sessao de um nome forte da comedia e do teatro contemporaneo brasileiro; ha datas anunciadas para 22 e 23 de junho."
  },
  {
    artist: "Tom Jobim Musical",
    title: "Tom Jobim Musical",
    subtitle: "Teatro musical no Teatro Positivo",
    date: "2026-05-30",
    startTime: "21:00",
    venue: "Teatro Positivo",
    neighborhood: "Campo Comprido",
    genre: "Teatro musical",
    scope: "Brasil",
    track: "culture",
    tier: "culture",
    relevance: 84,
    price: "Consultar ingressos",
    sourceId: "curitiba-cult",
    source: "Curitiba Cult",
    url: "https://curitibacult.com.br/",
    sourceUrl: "https://curitibacult.com.br/",
    lineup: ["Tom Jobim Musical"],
    tags: ["musical", "teatro", "mpb", "cultura"],
    whyRelevant: "Musical brasileiro de grande apelo em palco grande, listado na agenda cultural de Curitiba."
  },
  {
    artist: "Cirque du Soleil",
    title: "Alegria - Um Novo Dia",
    subtitle: "Temporada internacional no Expotrade",
    date: "2026-11-19",
    startTime: "20:00",
    venue: "Expotrade",
    neighborhood: "Pinhais",
    genre: "Circo contemporaneo",
    scope: "Internacional",
    track: "culture",
    tier: "stadium",
    relevance: 98,
    price: "Consultar ingressos na Eventim",
    sourceId: "cirque",
    source: "Cirque du Soleil",
    url: "https://cirquealegria.com.br/",
    sourceUrl: "https://cirquealegria.com.br/",
    lineup: ["Cirque du Soleil"],
    tags: ["circo", "espetaculo", "internacional", "temporada"],
    whyRelevant: "Temporada internacional de grande porte em Curitiba, de 19 de novembro a 13 de dezembro."
  }
];

const INTERNATIONAL_TERMS = [
  "dream theater",
  "men at work",
  "echo",
  "bunnymen",
  "spin doctors",
  "smash mouth",
  "candlebox",
  "rush",
  "cirque du soleil",
  "internacional",
  "turne mundial",
  "world tour",
  "south american tour"
];

const CULTURE_TERMS = [
  "comedia",
  "comediante",
  "stand up",
  "stand-up",
  "humor",
  "teatro",
  "espetaculo",
  "monologo",
  "musical",
  "cirque",
  "circo",
  "guaira",
  "teatro positivo"
];

const CONTENT_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon"
};

const server = http.createServer(async (request, response) => {
  try {
    const requestUrl = new URL(request.url, `http://${request.headers.host}`);

    if (requestUrl.pathname === "/api/events") {
      const payload = await collectEvents();
      sendJson(response, payload);
      return;
    }

    if (requestUrl.pathname === "/api/health") {
      sendJson(response, {
        id: "cwb-cultural-lineup",
        name: "CWB Cultural Lineup",
        city: "Curitiba",
        version: "2.0.0"
      });
      return;
    }

    await serveStatic(requestUrl.pathname, response);
  } catch (error) {
    console.error(error);
    sendJson(response, { error: "Erro interno no servidor local." }, 500);
  }
});

server.listen(PORT, () => {
  console.log(`Curitiba Cultural Lineup rodando em http://localhost:${PORT}`);
});

async function serveStatic(pathname, response) {
  const safePath = pathname === "/" ? "/index.html" : pathname;
  const filePath = path.normalize(path.join(PUBLIC_DIR, safePath));

  if (!filePath.startsWith(PUBLIC_DIR)) {
    sendText(response, "Caminho invalido.", 403);
    return;
  }

  try {
    const data = await readFile(filePath);
    const ext = path.extname(filePath);
    response.writeHead(200, { "Content-Type": CONTENT_TYPES[ext] || "application/octet-stream" });
    response.end(data);
  } catch {
    sendText(response, "Arquivo nao encontrado.", 404);
  }
}

async function collectEvents() {
  const errors = [];
  const sourceStatus = [{ sourceId: "curadoria", ok: true, count: CURATED_EVENTS.length }];
  const curated = CURATED_EVENTS.map(normalizeEvent);

  const comedy = await collectComedyClubEvents().then((events) => {
    sourceStatus.push({ sourceId: "comedy-club", ok: true, count: events.length });
    return events;
  }).catch((error) => {
    errors.push({ sourceId: "comedy-club", message: error.message });
    sourceStatus.push({ sourceId: "comedy-club", ok: false, count: 0 });
    return [];
  });

  const radar = await collectCuritibaCult().then((events) => {
    sourceStatus.push({ sourceId: "curitiba-cult", ok: true, count: events.length });
    return events;
  }).catch((error) => {
    errors.push({ sourceId: "curitiba-cult", message: error.message });
    sourceStatus.push({ sourceId: "curitiba-cult", ok: false, count: 0 });
    return [];
  });

  const today = todayIso();
  const events = dedupeEvents([...curated, ...comedy, ...radar])
    .filter((event) => event.date >= today || event.needsDateCheck)
    .sort((a, b) => eventSortKey(a, today).localeCompare(eventSortKey(b, today)));

  return {
    updatedAt: new Date().toISOString(),
    city: "Curitiba",
    focus: "Shows internacionais, comedia e atracoes culturais relevantes",
    sources: SOURCES,
    sourceStatus,
    errors,
    events
  };
}

async function collectComedyClubEvents() {
  const html = await fetchText("https://comedy.com.br/programacao/");
  const cards = html.match(/<article[^>]*class="[^"]*\bccc-standapp-card\b[^"]*"[\s\S]*?<\/article>/gi) || [];
  const events = [];

  for (const card of cards) {
    const title = cleanText(extractByRegex(card, /<h3[^>]*class="[^"]*\bccc-standapp-card-title\b[^"]*"[^>]*>([\s\S]*?)<\/h3>/i));
    const dateText = cleanText(extractByRegex(card, /<span[^>]*class="[^"]*\bccc-standapp-date\b[^"]*"[^>]*>([\s\S]*?)<\/span>/i));
    const startTime = cleanText(extractByRegex(card, /<span[^>]*class="[^"]*\bccc-standapp-time\b[^"]*"[^>]*>([\s\S]*?)<\/span>/i));
    const href = cleanText(extractByRegex(card, /<a class="ccc-standapp-button" href="([^"]+)"/i));
    const month = cleanText(extractByRegex(card, /data-month="([^"]+)"/i));
    const date = parseComedyClubDate(dateText, month);

    if (!title || !date) continue;

    events.push(normalizeEvent({
      artist: title,
      title,
      subtitle: "Programacao oficial do Curitiba Comedy Club",
      date,
      startTime,
      venue: "Curitiba Comedy Club",
      neighborhood: "Agua Verde",
      genre: inferComedyGenre(title),
      scope: "Curitiba",
      track: "comedy",
      tier: "comedy",
      relevance: inferComedyRelevance(title),
      price: "Consultar ingressos",
      sourceId: "comedy-club",
      source: "Curitiba Comedy Club",
      url: href || "https://comedy.com.br/programacao/",
      sourceUrl: "https://comedy.com.br/programacao/",
      lineup: [title],
      tags: inferComedyTags(title),
      whyRelevant: "Show de comedia listado na programacao oficial do primeiro comedy club do Brasil."
    }));
  }

  return events.slice(0, 24);
}

async function collectCuritibaCult() {
  const rss = await fetchText("https://curitibacult.com.br/feed/");
  const items = rss.match(/<item>[\s\S]*?<\/item>/gi) || [];

  return items.slice(0, 40).map((item) => {
    const title = cleanText(extractTag(item, "title"));
    const link = cleanText(extractTag(item, "link"));
    const description = cleanText(extractTag(item, "description"));
    const pubDate = cleanText(extractTag(item, "pubDate"));
    const text = `${title} ${description}`;

    if (!looksLikeRadarItem(text)) return null;

    const date = pubDate ? new Date(pubDate).toISOString().slice(0, 10) : todayIso();
    const guessedArtist = guessArtist(text);
    const isInternational = Boolean(guessedArtist) || includesAny(text, INTERNATIONAL_TERMS);
    const track = isInternational ? "international" : inferTrack(text);

    return normalizeEvent({
      artist: guessedArtist || title,
      title,
      subtitle: "Radar de noticia cultural",
      description,
      date,
      startTime: extractTime(text),
      venue: inferVenue(title, description),
      neighborhood: "",
      genre: isInternational ? "Musica internacional" : inferGenre(text),
      scope: isInternational ? "Conferir" : "Curitiba",
      track,
      tier: "radar",
      relevance: guessedArtist ? 76 : 62,
      price: inferPrice(description),
      sourceId: "curitiba-cult",
      source: "Curitiba Cult",
      sourceUrl: "https://curitibacult.com.br/",
      url: link,
      lineup: guessedArtist ? [guessedArtist] : [],
      tags: ["radar", "noticia", track],
      whyRelevant: "Entrou no radar automatico por conter sinais de atracao cultural relevante; confira data e ingressos no link.",
      needsDateCheck: true
    });
  }).filter(Boolean);
}

function normalizeEvent(event) {
  const title = event.title || event.artist;
  const date = event.date || todayIso();
  const lineup = Array.isArray(event.lineup) ? event.lineup : [event.artist].filter(Boolean);
  const track = event.track || "culture";

  return {
    id: event.id || makeId([event.artist, title, date, event.venue, event.url]),
    artist: event.artist || title,
    title,
    subtitle: event.subtitle || "",
    description: event.description || event.whyRelevant || "",
    category: trackLabel(track),
    country: event.country || event.scope || trackLabel(track),
    date,
    startTime: event.startTime || "",
    venue: event.venue || "Curitiba",
    neighborhood: event.neighborhood || "",
    genre: event.genre || "Cultura",
    scope: event.scope || "Curitiba",
    track,
    trackLabel: trackLabel(track),
    tier: event.tier || "culture",
    relevance: Number(event.relevance || 70),
    price: event.price || "Consultar ingressos",
    sourceId: event.sourceId || "curadoria",
    source: event.source || "Curadoria manual",
    sourceUrl: event.sourceUrl || event.url || "",
    url: event.url || event.sourceUrl || "",
    image: event.image || "",
    kind: "atracao-cultural",
    lineup,
    tags: Array.isArray(event.tags) ? event.tags : [],
    whyRelevant: event.whyRelevant || "",
    needsDateCheck: Boolean(event.needsDateCheck),
    discoveredAt: new Date().toISOString()
  };
}

function trackLabel(track) {
  if (track === "international") return "Internacional";
  if (track === "comedy") return "Comedia";
  return "Cultura";
}

function looksLikeRadarItem(text) {
  const value = normalize(text);
  const hasKnownArtist = Boolean(guessArtist(text));
  const hasInternationalTerm = includesAny(value, INTERNATIONAL_TERMS);
  const hasCultureTerm = includesAny(value, CULTURE_TERMS);
  const hasEventTerm = ["show", "ingresso", "festival", "palco", "estreia", "apresenta", "curitiba"].some((term) => value.includes(term));
  return hasEventTerm && (hasKnownArtist || hasInternationalTerm || hasCultureTerm);
}

function includesAny(text, terms) {
  const value = normalize(text);
  return terms.some((term) => value.includes(normalize(term)));
}

function guessArtist(text) {
  const value = normalize(text);
  const known = [
    "Dream Theater",
    "Men At Work",
    "Echo & The Bunnymen",
    "Spin Doctors",
    "Smash Mouth",
    "Candlebox",
    "Rush",
    "Cirque du Soleil",
    "ZZ Top",
    "Eagle-Eye Cherry",
    "Sticky Fingers"
  ];
  return known.find((artist) => value.includes(normalize(artist))) || "";
}

function eventSortKey(event, today) {
  const dateGroup = event.date >= today ? "0" : "2";
  const trackRank = event.track === "international" ? "0" : event.track === "comedy" ? "1" : "2";
  if (event.needsDateCheck) return `3-${trackRank}-${100 - event.relevance}-${event.date}-${event.artist}`;
  return `${dateGroup}-${event.date}-${trackRank}-${100 - event.relevance}-${event.artist}`;
}

function dedupeEvents(events) {
  const map = new Map();
  for (const event of events) {
    const key = normalize([event.artist, event.date, event.venue].filter(Boolean).join("|"));
    if (!map.has(key)) {
      map.set(key, event);
      continue;
    }

    const current = map.get(key);
    if ((event.relevance || 0) > (current.relevance || 0)) {
      map.set(key, event);
    }
  }
  return Array.from(map.values());
}

async function fetchText(url) {
  const response = await fetch(url, {
    headers: {
      "User-Agent": "CuritibaCulturalLineup/0.3 (+local personal app)",
      "Accept": "text/html,application/rss+xml,application/xml;q=0.9,*/*;q=0.8"
    }
  });

  if (!response.ok) {
    throw new Error(`Falha ao buscar ${url}: HTTP ${response.status}`);
  }

  return response.text();
}

function extractByRegex(value, regex) {
  const match = String(value || "").match(regex);
  return match ? match[1] : "";
}

function extractTag(xml, tagName) {
  const match = xml.match(new RegExp(`<${tagName}[^>]*>([\\s\\S]*?)<\\/${tagName}>`, "i"));
  return match ? match[1] : "";
}

function cleanText(value) {
  return decodeHtml(String(value || "")
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim());
}

function decodeHtml(value) {
  const named = {
    amp: "&",
    apos: "'",
    nbsp: " ",
    ndash: "-",
    mdash: "-",
    quot: "\"",
    rsquo: "'",
    lsquo: "'",
    rdquo: "\"",
    ldquo: "\"",
    ccedil: "c",
    Ccedil: "C",
    aacute: "a",
    Aacute: "A",
    eacute: "e",
    Eacute: "E",
    iacute: "i",
    Iacute: "I",
    oacute: "o",
    Oacute: "O",
    uacute: "u",
    Uacute: "U",
    atilde: "a",
    Atilde: "A",
    otilde: "o",
    Otilde: "O",
    acirc: "a",
    ecirc: "e",
    ocirc: "o"
  };

  return value.replace(/&(#x?[0-9a-f]+|[a-zA-Z]+);/g, (entity, code) => {
    if (code[0] === "#") {
      const isHex = code[1]?.toLowerCase() === "x";
      const number = Number.parseInt(code.slice(isHex ? 2 : 1), isHex ? 16 : 10);
      return Number.isFinite(number) ? String.fromCodePoint(number) : entity;
    }
    return Object.prototype.hasOwnProperty.call(named, code) ? named[code] : entity;
  });
}

function parseComedyClubDate(dateText, monthValue) {
  const match = String(dateText || "").match(/(\d{1,2})\s+([a-zA-Z]+)/);
  if (!match) return "";

  const day = match[1].padStart(2, "0");
  if (monthValue && /^\d{4}-\d{2}$/.test(monthValue)) {
    return `${monthValue}-${day}`;
  }

  const month = monthNumber(match[2]);
  if (!month) return "";
  return `2026-${month}-${day}`;
}

function monthNumber(value) {
  const months = {
    jan: "01",
    fev: "02",
    mar: "03",
    abr: "04",
    mai: "05",
    jun: "06",
    jul: "07",
    ago: "08",
    set: "09",
    out: "10",
    nov: "11",
    dez: "12"
  };
  return months[normalize(value).slice(0, 3)] || "";
}

function inferComedyGenre(title) {
  const value = normalize(title);
  if (value.includes("magico") || value.includes("hipnose")) return "Comedia / magia";
  if (value.includes("mix")) return "Stand-up mix";
  if (value.includes("comedia")) return "Comedia";
  return "Stand-up comedy";
}

function inferComedyTags(title) {
  const tags = ["comedia", "stand-up", "curitiba"];
  const value = normalize(title);
  if (value.includes("magico")) tags.push("magia");
  if (value.includes("hipnose")) tags.push("hipnose");
  if (value.includes("mix")) tags.push("mix");
  return tags;
}

function inferComedyRelevance(title) {
  const value = normalize(title);
  if (value.includes("afonso padilha")) return 92;
  if (value.includes("eros prado")) return 86;
  if (value.includes("helio de la pena")) return 88;
  if (value.includes("daniel duncan")) return 82;
  return 72;
}

function inferTrack(text) {
  const value = normalize(text);
  if (value.includes("comedia") || value.includes("comediante") || value.includes("stand") || value.includes("humor")) return "comedy";
  return "culture";
}

function inferGenre(text) {
  const value = normalize(text);
  if (value.includes("comedia") || value.includes("comediante") || value.includes("stand") || value.includes("humor")) return "Comedia";
  if (value.includes("musical")) return "Teatro musical";
  if (value.includes("cirque") || value.includes("circo")) return "Circo contemporaneo";
  if (value.includes("teatro") || value.includes("peca")) return "Teatro";
  return "Cultura";
}

function inferVenue(title, description) {
  const text = normalize(`${title} ${description}`);
  const knownVenues = [
    "Pedreira Paulo Leminski",
    "Live Curitiba",
    "Igloo Super Hall",
    "White Hall",
    "Jockey Eventos",
    "Arena da Baixada",
    "Teatro Positivo",
    "Teatro Guaira",
    "Opera de Arame",
    "Expotrade",
    "Curitiba Comedy Club"
  ];
  return knownVenues.find((venue) => text.includes(normalize(venue))) || "Curitiba";
}

function inferPrice(description) {
  const text = normalize(description);
  if (text.includes("gratuito") || text.includes("entrada franca")) return "Gratuito";
  if (text.includes("ingresso") || text.includes("ingressos")) return "Consultar ingressos";
  return "Consultar";
}

function extractTime(text) {
  const match = String(text || "").match(/\b([01]?\d|2[0-3])[:h]([0-5]\d)?\b/i);
  if (!match) return "";
  const hour = match[1].padStart(2, "0");
  const minute = (match[2] || "00").padStart(2, "0");
  return `${hour}:${minute}`;
}

function todayIso() {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).formatToParts(new Date());
  const get = (type) => parts.find((part) => part.type === type)?.value;
  return `${get("year")}-${get("month")}-${get("day")}`;
}

function makeId(parts) {
  return createHash("sha1").update(parts.filter(Boolean).join("|")).digest("hex").slice(0, 16);
}

function normalize(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

function sendJson(response, payload, status = 200) {
  response.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  response.end(JSON.stringify(payload, null, 2));
}

function sendText(response, text, status = 200) {
  response.writeHead(status, { "Content-Type": "text/plain; charset=utf-8" });
  response.end(text);
}
