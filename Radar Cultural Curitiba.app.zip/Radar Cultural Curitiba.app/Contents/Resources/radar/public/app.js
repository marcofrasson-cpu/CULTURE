const STORAGE_KEY = "curitiba-cultural-lineup:v2";

const state = {
  events: [],
  sources: [],
  sourceStatus: [],
  saved: {},
  filters: {
    search: "",
    period: "all",
    genre: "all"
  },
  lastSync: ""
};

const elements = {
  syncButton: document.querySelector("#syncButton"),
  exportButton: document.querySelector("#exportButton"),
  searchInput: document.querySelector("#searchInput"),
  genreFilter: document.querySelector("#genreFilter"),
  segments: Array.from(document.querySelectorAll("[data-period]")),
  lineupGrid: document.querySelector("#lineupGrid"),
  radarList: document.querySelector("#radarList"),
  sourceList: document.querySelector("#sourceList"),
  alertBox: document.querySelector("#alertBox"),
  lastSyncText: document.querySelector("#lastSyncText"),
  metricHeadliners: document.querySelector("#metricHeadliners"),
  metricUpcoming: document.querySelector("#metricUpcoming"),
  metricSaved: document.querySelector("#metricSaved")
};

loadState();
bindEvents();
render();
syncEvents({ quiet: true });

function bindEvents() {
  elements.syncButton.addEventListener("click", () => syncEvents());
  elements.exportButton.addEventListener("click", exportSavedShows);
  elements.searchInput.addEventListener("input", (event) => {
    state.filters.search = event.target.value;
    render();
  });
  elements.genreFilter.addEventListener("change", (event) => {
    state.filters.genre = event.target.value;
    render();
  });
  elements.segments.forEach((button) => {
    button.addEventListener("click", () => {
      state.filters.period = button.dataset.period;
      render();
    });
  });
  elements.lineupGrid.addEventListener("click", handleShowAction);
  elements.radarList.addEventListener("click", handleShowAction);
}

async function syncEvents(options = {}) {
  setLoading(true);
  showAlert("");

  try {
    const response = await fetch("/api/events");
    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const payload = await response.json();
    state.events = payload.events || [];
    state.sources = payload.sources || [];
    state.sourceStatus = payload.sourceStatus || [];
    state.lastSync = payload.updatedAt || new Date().toISOString();

    if (payload.errors?.length) {
      showAlert("Algumas fontes automaticas falharam. A curadoria manual continua disponivel.");
    } else if (!options.quiet) {
      showAlert("Lineup atualizado.");
    }

    saveState();
    render();
  } catch (error) {
    showAlert("Nao consegui atualizar agora. O servidor local precisa estar aberto e com internet.");
    console.error(error);
  } finally {
    setLoading(false);
  }
}

function handleShowAction(event) {
  const button = event.target.closest("[data-action]");
  if (!button) return;

  const show = state.events.find((item) => item.id === button.dataset.id);
  if (!show) return;

  if (button.dataset.action === "save") {
    state.saved[show.id] = !state.saved[show.id];
    saveState();
    render();
  }

  if (button.dataset.action === "ics") {
    downloadIcs([show], `${slugify(show.artist)}.ics`);
  }
}

function render() {
  renderGenreOptions();
  renderSegments();
  renderMetrics();
  renderLineup();
  renderRadar();
  renderSources();
  renderLastSync();
  refreshIcons();
}

function renderGenreOptions() {
  const current = elements.genreFilter.value || state.filters.genre;
  const genres = unique(state.events.map((event) => event.genre).filter(Boolean)).sort();
  elements.genreFilter.innerHTML = [
    `<option value="all">Todos</option>`,
    ...genres.map((genre) => `<option value="${escapeHtml(genre)}">${escapeHtml(genre)}</option>`)
  ].join("");
  elements.genreFilter.value = genres.includes(current) ? current : "all";
  state.filters.genre = elements.genreFilter.value;
}

function renderSegments() {
  elements.segments.forEach((button) => {
    button.classList.toggle("active", button.dataset.period === state.filters.period);
  });
}

function renderMetrics() {
  const curated = state.events.filter((event) => !event.needsDateCheck);
  const international = curated.filter((event) => event.track === "international");
  const comedy = curated.filter((event) => event.track === "comedy");
  const saved = state.events.filter((event) => state.saved[event.id]);

  elements.metricHeadliners.textContent = international.length;
  elements.metricUpcoming.textContent = comedy.length;
  elements.metricSaved.textContent = saved.length;
}

function renderLineup() {
  const events = filteredEvents().filter((event) => !event.needsDateCheck);

  if (!events.length) {
    elements.lineupGrid.innerHTML = emptyState("Nenhuma atracao nesta selecao", "Troque filtros ou atualize as fontes.");
    return;
  }

  elements.lineupGrid.innerHTML = events.map(renderShowCard).join("");
}

function renderRadar() {
  const radar = state.events.filter((event) => event.needsDateCheck);

  if (!radar.length) {
    elements.radarList.innerHTML = emptyState("Sem novos sinais automaticos", "Quando um RSS indicar show, comedia ou cultura, ele aparece aqui para conferencia.");
    return;
  }

  elements.radarList.innerHTML = radar.map(renderRadarItem).join("");
}

function renderShowCard(show) {
  const saved = Boolean(state.saved[show.id]);
  const date = formatDate(show.date);
  const tags = (show.tags || []).slice(0, 4).map((tag) => `<span>${escapeHtml(tag)}</span>`).join("");
  const lineup = show.lineup?.length ? show.lineup.join(" + ") : show.artist;
  const statusLabel = tierLabel(show);
  const scopeLabel = show.scope || show.country || show.trackLabel || show.category || "Curitiba";

  return `
    <article class="show-card ${show.tier} ${show.track || "culture"}">
      <div class="show-date">
        <strong>${date.day}</strong>
        <span>${date.month}</span>
      </div>
      <div class="show-body">
        <div class="show-kicker">
          <span>${escapeHtml(statusLabel)}</span>
          <span>${escapeHtml(show.trackLabel || show.category || "Cultura")}</span>
          <span>${escapeHtml(scopeLabel)}</span>
          <span>${show.relevance}/100</span>
        </div>
        <h3>${escapeHtml(show.artist)}</h3>
        <p class="show-subtitle">${escapeHtml(show.subtitle || show.title)}</p>
        <div class="show-meta">
          <span><i data-lucide="map-pin"></i>${escapeHtml(show.venue)}</span>
          <span><i data-lucide="calendar-days"></i>${escapeHtml(date.full)}${show.startTime ? `, ${escapeHtml(show.startTime)}` : ""}</span>
          <span><i data-lucide="music-2"></i>${escapeHtml(show.genre)}</span>
        </div>
        <p class="why">${escapeHtml(show.whyRelevant)}</p>
        <div class="tag-row">${tags}</div>
        <div class="lineup-names">${escapeHtml(lineup)}</div>
        <div class="show-actions">
          <a class="action-link" href="${escapeAttribute(show.url)}" target="_blank" rel="noreferrer">
            <i data-lucide="ticket"></i>
            <span>Ingressos</span>
          </a>
          <button class="action-link ${saved ? "active" : ""}" type="button" data-action="save" data-id="${show.id}">
            <i data-lucide="star"></i>
            <span>${saved ? "Marcado" : "Marcar"}</span>
          </button>
          <button class="action-link" type="button" data-action="ics" data-id="${show.id}">
            <i data-lucide="calendar-plus"></i>
            <span>Agenda</span>
          </button>
        </div>
      </div>
    </article>
  `;
}

function renderRadarItem(show) {
  const saved = Boolean(state.saved[show.id]);
  return `
    <article class="radar-item">
      <div>
        <span class="radar-label">${escapeHtml(show.trackLabel || "checar")}</span>
        <h3>${escapeHtml(show.artist)}</h3>
        <p>${escapeHtml(show.title)}</p>
      </div>
      <div class="radar-actions">
        <a class="action-link" href="${escapeAttribute(show.url)}" target="_blank" rel="noreferrer">
          <i data-lucide="external-link"></i>
          <span>Abrir</span>
        </a>
        <button class="action-link ${saved ? "active" : ""}" type="button" data-action="save" data-id="${show.id}">
          <i data-lucide="star"></i>
          <span>${saved ? "Marcado" : "Marcar"}</span>
        </button>
      </div>
    </article>
  `;
}

function renderSources() {
  const statusBySource = new Map(state.sourceStatus.map((item) => [item.sourceId, item]));

  if (!state.sources.length) {
    elements.sourceList.innerHTML = emptyState("Fontes ainda nao carregadas", "Atualize para ver as fontes.");
    return;
  }

  elements.sourceList.innerHTML = state.sources.map((source) => {
    const status = statusBySource.get(source.id);
    const count = status ? `${status.count} itens` : source.mode;

    return `
      <article class="source-card">
        <div class="source-top">
          <h3>${escapeHtml(source.name)}</h3>
          <span>${escapeHtml(count)}</span>
        </div>
        <p>${escapeHtml(source.note)}</p>
        <a href="${escapeAttribute(source.url)}" target="_blank" rel="noreferrer">Abrir fonte</a>
      </article>
    `;
  }).join("");
}

function renderLastSync() {
  elements.lastSyncText.textContent = state.lastSync
    ? `Atualizado em ${formatDateTime(state.lastSync)}.`
    : "Ainda nao atualizado nesta sessao.";
}

function filteredEvents() {
  const search = normalize(state.filters.search);
  const today = localToday();

  return state.events.filter((show) => {
    const haystack = normalize([
      show.artist,
      show.title,
      show.subtitle,
      show.genre,
      show.scope,
      show.country,
      show.track,
      show.trackLabel,
      show.category,
      show.venue,
      show.tags?.join(" ")
    ].join(" "));

    if (search && !haystack.includes(search)) return false;
    if (state.filters.genre !== "all" && show.genre !== state.filters.genre) return false;
    if (state.filters.period !== "all" && show.track !== state.filters.period) return false;
    if (!show.needsDateCheck && show.date < today) return false;

    return true;
  }).sort((a, b) => {
    const checkedA = a.needsDateCheck ? 1 : 0;
    const checkedB = b.needsDateCheck ? 1 : 0;
    return `${checkedA}-${a.date}-${100 - a.relevance}`.localeCompare(`${checkedB}-${b.date}-${100 - b.relevance}`);
  });
}

function exportSavedShows() {
  const selected = state.events.filter((event) => state.saved[event.id] && !event.needsDateCheck);
  if (!selected.length) {
    showAlert("Marque uma atracao confirmada antes de exportar.");
    return;
  }
  downloadIcs(selected, "agenda-cultural-curitiba.ics");
}

function downloadIcs(events, fileName) {
  const body = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//CWB Cultural Lineup//PT-BR",
    "CALSCALE:GREGORIAN",
    ...events.flatMap(toIcsEvent),
    "END:VCALENDAR"
  ].join("\r\n");

  const blob = new Blob([body], { type: "text/calendar;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  link.click();
  URL.revokeObjectURL(url);
}

function toIcsEvent(event) {
  const eventTime = event.startTime || "20:00";
  const startDate = new Date(`${event.date}T${eventTime}:00`);
  const endDate = new Date(startDate.getTime() + 3 * 60 * 60 * 1000);

  return [
    "BEGIN:VEVENT",
    `UID:${event.id}@cwb-cultural-lineup.local`,
    `DTSTAMP:${new Date().toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "")}`,
    `DTSTART;TZID=America/Sao_Paulo:${formatIcsDate(startDate)}`,
    `DTEND;TZID=America/Sao_Paulo:${formatIcsDate(endDate)}`,
    `SUMMARY:${escapeIcs(event.artist)} - Curitiba`,
    `LOCATION:${escapeIcs(event.venue)}`,
    `DESCRIPTION:${escapeIcs([event.title, event.whyRelevant, event.url].filter(Boolean).join("\\n"))}`,
    event.url ? `URL:${escapeIcs(event.url)}` : "",
    "END:VEVENT"
  ].filter(Boolean);
}

function tierLabel(show) {
  if (show.tier === "stadium") return "grande porte";
  if (show.tier === "headliner") return "headliner";
  if (show.tier === "comedy") return "comedia";
  if (show.tier === "culture") return "cultura";
  if (show.tier === "radar") return "checar";
  return show.tier || "agenda";
}

function setLoading(isLoading) {
  elements.syncButton.disabled = isLoading;
  elements.syncButton.querySelector("span").textContent = isLoading ? "Atualizando" : "Atualizar";
}

function showAlert(message) {
  elements.alertBox.hidden = !message;
  elements.alertBox.textContent = message;
}

function emptyState(title, body) {
  return `
    <div class="empty-state">
      <h3>${escapeHtml(title)}</h3>
      <p>${escapeHtml(body)}</p>
    </div>
  `;
}

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
    state.saved = saved.saved || {};
    state.events = Array.isArray(saved.events) ? saved.events : [];
    state.sources = Array.isArray(saved.sources) ? saved.sources : [];
    state.sourceStatus = Array.isArray(saved.sourceStatus) ? saved.sourceStatus : [];
    state.lastSync = saved.lastSync || "";
  } catch {
    localStorage.removeItem(STORAGE_KEY);
  }
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({
    saved: state.saved,
    events: state.events,
    sources: state.sources,
    sourceStatus: state.sourceStatus,
    lastSync: state.lastSync
  }));
}

function refreshIcons() {
  if (window.lucide) {
    window.lucide.createIcons();
  }
}

function formatDate(date) {
  const parsed = new Date(`${date}T12:00:00`);
  return {
    day: new Intl.DateTimeFormat("pt-BR", { day: "2-digit" }).format(parsed),
    month: new Intl.DateTimeFormat("pt-BR", { month: "short" }).format(parsed).replace(".", ""),
    full: new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "short", year: "numeric" }).format(parsed)
  };
}

function formatDateTime(value) {
  return new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "short",
    timeStyle: "short"
  }).format(new Date(value));
}

function formatIcsDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const hour = String(date.getHours()).padStart(2, "0");
  const minute = String(date.getMinutes()).padStart(2, "0");
  return `${year}${month}${day}T${hour}${minute}00`;
}

function localToday() {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Sao_Paulo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).formatToParts(new Date());
  const get = (type) => parts.find((part) => part.type === type)?.value;
  return `${get("year")}-${get("month")}-${get("day")}`;
}

function unique(values) {
  return Array.from(new Set(values));
}

function slugify(value) {
  return normalize(value).replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

function normalize(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function escapeAttribute(value) {
  return escapeHtml(value).replaceAll("`", "&#096;");
}

function escapeIcs(value) {
  return String(value || "")
    .replaceAll("\\", "\\\\")
    .replaceAll("\n", "\\n")
    .replaceAll(",", "\\,")
    .replaceAll(";", "\\;");
}
