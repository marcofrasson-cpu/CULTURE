# CWB Cultural Lineup

Site pessoal para acompanhar shows internacionais, stand-up, comedia, teatro e grandes atracoes culturais em Curitiba, com uma apresentacao inspirada em lineup de festival.

## Como rodar no navegador

```bash
node server.js
```

Depois abra:

```text
http://localhost:3000
```

## Como abrir como app desktop no macOS

O app desktop fica em:

```text
dist/Radar Cultural Curitiba Standalone.app
```

Para abrir:

```bash
open "dist/Radar Cultural Curitiba Standalone.app"
```

Se voce alterar o codigo, feche o app aberto e rode:

```bash
desktop/build-macos-app.sh
```

## O que esta versao faz

- Mostra atracoes culturais relevantes em Curitiba.
- Separa a agenda em Internacionais, Comedia e Cultura.
- Usa um visual de festival, com hero image e cards de lineup.
- Mantem uma curadoria inicial com Rush, Somos Rock Festival, Dream Theater, Men At Work, Clube dos Canalhas, Gregorio Duvivier, Tom Jobim Musical e Cirque du Soleil.
- Coleta automaticamente a programacao do Curitiba Comedy Club.
- Usa o RSS do Curitiba Cult como radar automatico para possiveis shows, pecas, comedia e grandes espetaculos.
- Permite marcar atracoes e exportar para calendario `.ics`.
- Lista fontes para confirmar ingressos e dados.

## Como o projeto esta organizado

- `server.js`: servidor local, curadoria, fontes e filtros culturais.
- `public/index.html`: estrutura do site.
- `public/styles.css`: visual do site.
- `public/app.js`: filtros, cards, marcacoes e exportacao.
- `public/assets/hero-international-shows.png`: imagem hero gerada para o projeto.
- `desktop/`: scripts para empacotar e abrir no macOS.

## Como aprender mexendo

1. Para adicionar uma atracao fixa, edite o array `CURATED_EVENTS` em `server.js`.
2. Para mudar a regra do radar automatico, edite `INTERNATIONAL_TERMS`, `CULTURE_TERMS` e `looksLikeRadarItem`.
3. Para ajustar filtros e cards, veja `filteredEvents` e `renderShowCard` em `public/app.js`.
4. Para ajustar o visual, comece por `.hero`, `.show-card` e `.toolbar` em `public/styles.css`.
5. Depois de alterar, rode `node --check server.js` e `node --check public/app.js`.
