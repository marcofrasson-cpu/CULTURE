#!/bin/zsh
set -u

APP_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PID_FILE="$APP_ROOT/.desktop/server.pid"

if [ ! -f "$PID_FILE" ]; then
  echo "Nenhum PID salvo. Se o servidor estiver aberto, feche pelo Monitor de Atividade ou reinicie o computador."
  exit 0
fi

PID="$(cat "$PID_FILE")"

if kill -0 "$PID" >/dev/null 2>&1; then
  kill "$PID"
  echo "Radar Cultural encerrado."
else
  echo "O processo salvo nao esta mais rodando."
fi
