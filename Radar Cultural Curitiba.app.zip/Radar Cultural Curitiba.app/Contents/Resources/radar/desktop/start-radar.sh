#!/bin/zsh
set -u

APP_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LOG_DIR="$APP_ROOT/.desktop"
PID_FILE="$LOG_DIR/server.pid"
LOG_FILE="$LOG_DIR/server.log"
LAUNCHER_LOG="$LOG_DIR/launcher.log"
DEFAULT_PORT="${RADAR_PORT:-3000}"
MODE="${1:-background}"

mkdir -p "$LOG_DIR"

log_line() {
  printf "%s %s\n" "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LAUNCHER_LOG"
}

log_line "launcher-start mode=$MODE app_root=$APP_ROOT"

find_node() {
  if command -v node >/dev/null 2>&1; then
    command -v node
    return 0
  fi

  if [ -x "/Applications/Codex.app/Contents/Resources/node" ]; then
    echo "/Applications/Codex.app/Contents/Resources/node"
    return 0
  fi

  return 1
}

is_radar_running() {
  local port="$1"
  curl -fsS "http://127.0.0.1:$port/api/health" 2>/dev/null | grep -q "cwb-cultural-lineup"
}

is_port_busy() {
  local port="$1"
  lsof -ti "tcp:$port" >/dev/null 2>&1
}

choose_port() {
  local first="$1"
  local candidate

  if is_radar_running "$first"; then
    echo "$first"
    return 0
  fi

  candidate="$first"
  while [ "$candidate" -le 3010 ]; do
    if ! is_port_busy "$candidate"; then
      echo "$candidate"
      return 0
    fi
    candidate=$((candidate + 1))
  done

  return 1
}

NODE_BIN="$(find_node)" || {
  log_line "node-not-found"
  osascript -e 'display alert "Node.js nao encontrado" message "Instale o Node.js ou abra este projeto pelo Codex para usar o app desktop."'
  exit 1
}
log_line "mode=$MODE node=$NODE_BIN"

PORT="$(choose_port "$DEFAULT_PORT")" || {
  log_line "port-not-found"
  osascript -e 'display alert "Portas ocupadas" message "Nao encontrei uma porta livre entre 3000 e 3010."'
  exit 1
}
log_line "port=$PORT"

open_radar() {
  local url="http://localhost:$PORT"

  if [ -d "/Applications/Google Chrome.app" ]; then
    open -na "Google Chrome" --args --app="$url"
  else
    open "$url"
  fi
}

if is_radar_running "$PORT"; then
  log_line "already-running"
  open_radar
  exit 0
fi

if [ "$MODE" = "--foreground" ]; then
  cd "$APP_ROOT" || exit 1
  log_line "starting-foreground"
  (sleep 1 && open_radar) >/dev/null 2>&1 &
  exec env RADAR_PORT="$PORT" "$NODE_BIN" server.js >> "$LOG_FILE" 2>&1
else
  cd "$APP_ROOT" || exit 1
  log_line "starting-background"
  nohup env RADAR_PORT="$PORT" "$NODE_BIN" server.js >> "$LOG_FILE" 2>&1 < /dev/null &
  SERVER_PID="$!"
  echo "$SERVER_PID" > "$PID_FILE"
  disown "$SERVER_PID" 2>/dev/null || true
  sleep 1
  open_radar
fi
